<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:asx="http://www.sap.com/abapxml" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="html"/>
	<xsl:template match="/">
		<html>
			<head>
				<title>SAP Readiness Check</title>
				<link href="fui-site.css" rel="stylesheet" type="text/css"/>
			</head>
			<body>
				<article class="fd-page">
					<header class="fd-page__header">
						<div class="fd-action-bar">
							<div class="fd-action-bar__header">
								<h1 class="fd-action-bar__title">SAP Readiness Check - FDQ</h1>
							</div>
						</div>
						<p class="fd-action-bar__description">The 
							<b>FDQ_ML.xml</b>
							collects FI-ML data.</p>
						<p class="fd-action-bar__description">Below is general data</p>
						<table class="fd-table">
							<tr>
								<th>Client</th>
								<th>System ID</th>
								<th>Analysis Date</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/FIML_GENERAL_DATA/item">
								<tr>
									<td>
										<xsl:value-of select="CLIENT"/>
									</td>
									<td>
										<xsl:value-of select="SYSTEM_ID"/>
									</td>
									<td>
										<xsl:value-of select="ANALYSE_DATE"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below metrics for FI-ML</p>
						<table class="fd-table">
							<tr>
								<th>Total number of valuation history records</th>
								<th>Total number of valuation areas</th>
								<th>Number of active valuation areas</th>
								<th>Number of inactive valuation areas</th>
								<th>Number of actual costings enabled for valuation areas</th>
								<th>Number of active valuation areas with one currency</th>
								<th>Number of active valuation areas with two currencies</th>
								<th>Number of active valuation areas with three currencies</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/FIML_METRICS/item">
								<tr>
									<td>
										<xsl:value-of select="TOTAL_NBR_XBEWH"/>
									</td>
									<td>
										<xsl:value-of select="TOTAL_NBR_VALAREA"/>
									</td>
									<td>
										<xsl:value-of select="NBR_ACT_VALAREA"/>
									</td>
									<td>
										<xsl:value-of select="NBR_INACT_VALAREA"/>
									</td>
									<td>
										<xsl:value-of select="NBR_ACT_COST_ENABLED"/>
									</td>
									<td>
										<xsl:value-of select="NBR_VALAREA_CURTP1"/>
									</td>
									<td>
										<xsl:value-of select="NBR_VALAREA_CURTP2"/>
									</td>
									<td>
										<xsl:value-of select="NBR_VALAREA_CURTP3"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is list of status for all reconciliation results</p>
						<table class="fd-table">
							<tr>
								<th>Run id</th>
								<th>Fisacl Year</th>
								<th>Company code</th>
								<th>valuation area</th>
								<th>Material number</th>
								<th>Message umber</th>
								<th>Message Id</th>
								<th>Message type</th>
								<th>Number of errors</th>
								<th>Message text</th>
								<th>Company code desciption</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/FIML_ALL_RES/item">
								<tr>
									<td>
										<xsl:value-of select="RUN_ID"/>
									</td>
									<td>
										<xsl:value-of select="FISCAL_YEAR"/>
									</td>
									<td>
										<xsl:value-of select="COMPANY_CODE"/>
									</td>
									<td>
										<xsl:value-of select="VAL_AREA"/>
									</td>
									<td>
										<xsl:value-of select="MATNR"/>
									</td>
									<td>
										<xsl:value-of select="MSGNO"/>
									</td>
									<td>
										<xsl:value-of select="MSGID"/>
									</td>
									<td>
										<xsl:value-of select="MSGTY"/>
									</td>
									<td>
										<xsl:value-of select="NBR_ERRORS"/>
									</td>
									<td>
										<xsl:value-of select="MSG_TEXT"/>
									</td>
									<td>
										<xsl:value-of select="COMPANY_CODE_DESCR"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is list of status for all valuation areas</p>
						<table class="fd-table">
							<tr>
								<th>valuation area</th>
								<th>Status</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/ALL_VALAREA_LIST/item">
								<tr>
									<td>
										<xsl:value-of select="VALAREA"/>
									</td>
									<td>
										<xsl:value-of select="ACTIVE"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is list of Material numbers by fiscal year</p>
						<table class="fd-table">
							<tr>
								<th>Fiscal year</th>
								<th>Material Number</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/MATNR_FY/item">
								<tr>
									<td>
										<xsl:value-of select="FISCAL_YEAR"/>
									</td>
									<td>
										<xsl:value-of select="TOTAL_NBR_MATNR"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is list of Material numbers by valuation areas</p>
						<table class="fd-table">
							<tr>
								<th>Valuation area</th>
								<th>Material Number</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/MATNR_VALAREA/item">
								<tr>
									<td>
										<xsl:value-of select="VAL_AREA"/>
									</td>
									<td>
										<xsl:value-of select="TOTAL_NBR_MATNR"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is list of actual costing enabled for valuation areas</p>
						<table class="fd-table">
							<tr>
								<th>Valuation area</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/ACTVALAREA_ACTCOST/item">
								<tr>
									<td>
										<xsl:value-of select="ACT_VALAREA"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is the list of all reconciliation results</p>
						<table class="fd-table">
							<tr>
								<th>Run Id</th>
								<th>Fiscal year</th>
								<th>Company code</th>
								<th>valuation area</th>
								<th>Material number</th>
								<th>Message Number</th>
								<th>Message Class</th>
								<th>Message Type</th>
								<th>Number of errors</th>
								<th>Message text</th>
								<th>Company Code Description</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/FIML_ALL_RES/item">
								<tr>
									<td>
										<xsl:value-of select="RUN_ID"/>
									</td>
									<td>
										<xsl:value-of select="FISCAL_YEAR"/>
									</td>
									<td>
										<xsl:value-of select="COMPANY_CODE"/>
									</td>
									<td>
										<xsl:value-of select="VAL_AREA"/>
									</td>
									<td>
										<xsl:value-of select="MATNR"/>
									</td>
									<td>
										<xsl:value-of select="MSGNO"/>
									</td>
									<td>
										<xsl:value-of select="MSGID"/>
									</td>
									<td>
										<xsl:value-of select="MSGTY"/>
									</td>
									<td>
										<xsl:value-of select="NBR_ERRORS"/>
									</td>
									<td>
										<xsl:value-of select="MSG_TEXT"/>
									</td>
									<td>
										<xsl:value-of select="COMPANY_CODE_DESCR"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
						<p class="fd-action-bar__description">Below is the list of run ids</p>
						<table class="fd-table">
							<tr>
								<th>Run ID</th>
							</tr>
							<xsl:for-each select="/asx:abap/asx:values/RUNIDS/item">
								<tr>
									<td>
										<xsl:value-of select="RUN_ID"/>
									</td>
								</tr>
							</xsl:for-each>
						</table>
					</header>
				</article>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>