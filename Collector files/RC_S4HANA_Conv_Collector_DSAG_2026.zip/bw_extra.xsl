<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - active BW extractors
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>bw_extra.xml</b>collects the active BW extractor
                   from table ROOSOURCE with OBJVERS = 'A'. More detail see SAP Note
                   <a href = "https://launchpad.support.sap.com/#/notes/2500202"
                   target="_blank">2500202</a>

                 </p>
                <table class="fd-table">
                  <tr>
                    <th>DataSource (OSOA/OSOD)</th>
                    <th>DataSource Extractor</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/ROOSOURCE/item">
                    <tr>
                      <td><xsl:value-of select="OLTPSOURCE"/></td>
                      <td><xsl:value-of select="EXTRACTOR"/></td>
                    </tr>
                  </xsl:for-each>

                </table>
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
