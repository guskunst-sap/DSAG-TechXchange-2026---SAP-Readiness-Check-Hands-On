<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="syntax.css"/>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - Usage Data
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                   Here is the usage data from t-code ST03N.

                 </p>
                 <table class="fd-table">
                   <tr>
                     <th>Start Date for the collected month</th>
                   </tr>

                   <xsl:for-each select="/asx:abap/asx:values/START_MONTH/SYDATUM">
                     <tr>
                       <td><xsl:value-of select="."/></td>
                     </tr>
                   </xsl:for-each>

                 </table>

                <table class="fd-table">
                  <tr>
                    <th>Entity Name</th>
                    <th>Entity Type</th>
                    <th>Execution Time</th>
                    <th>Custom Object</th>
                    <th>Package</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/TRANS_USAGE_DATA/item">
                    <tr>
                      <td><xsl:value-of select="OBJECT_NAME"/></td>
                      <td><xsl:value-of select="OBJECT_TYPE"/></td>
                      <td><xsl:value-of select="USAGE_COUNTER"/></td>
                      <td><xsl:value-of select="CUSTOM_OBJ_FLAG"/></td>
                      <td><xsl:value-of select="DEVCLASS"/></td>
                    </tr>
                  </xsl:for-each>

                </table>
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
