<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - data volume management
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>dvm.xml</b> collects the raw data for DVM calculation.
                   The XML is not rawstring, but it exports exactly what you
                   see in the system by following the steps (transaction code
                   ST13 -> select ANALYSISBROWSER for the tool name and execute
                   ->  the latest analysis with title “Readiness Check ST14
                   analysis” -> View Data)

                 </p>



              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
