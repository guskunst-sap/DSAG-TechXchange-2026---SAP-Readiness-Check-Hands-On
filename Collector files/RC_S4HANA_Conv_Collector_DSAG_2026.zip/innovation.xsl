<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - Innovation Data
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                   Here is the count data to determine the innovation potential

                 </p>

                <table class="fd-table">
                  <tr>
                    <th>Name</th>
                    <th>Key</th>
                    <th>Value</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/SAP_INNOVATION_DATA/item">
                    <tr>
                      <td><xsl:value-of select="NAME_DESC"/></td>
                      <td><xsl:value-of select="KEY_DESC"/></td>
                      <td><xsl:value-of select="VALUE"/></td>
                    </tr>
                  </xsl:for-each>

                </table>
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
