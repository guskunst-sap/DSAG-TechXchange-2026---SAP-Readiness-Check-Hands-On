<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check for SAP Cloud ALM</title>
        <link rel="stylesheet" type="text/css" href="alm-fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check for SAP Cloud ALM
                    </h1>


                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>solman_usage_profile.xml</b> collects the SAP Solution Manager usage profile.
                 </p>
                <table class="fd-table">
                  <tr>
                    <td>System</td>
                    <td><xsl:value-of select="/asx:abap/asx:values/CHECK_INFO/SYSTEM" /></td>
                  </tr>

                  <tr>
                    <td>Client</td>
                    <td><xsl:value-of select="/asx:abap/asx:values/CHECK_INFO/CLIENT" /></td>
                  </tr>

                    <tr>
                      <td>Start Date</td>
                      <td><xsl:value-of select="/asx:abap/asx:values/CHECK_INFO/START_DATE" /></td>
                    </tr>
                 <tr>
                    <td>End Date</td>
                    <td><xsl:value-of select="/asx:abap/asx:values/CHECK_INFO/END_DATE" /></td>
                  </tr>

                </table>
                
                 <p class="fd-action-bar__description">

                   Below is the list of all capabilities from each scenario:
                 </p>
                 
                  
				
				
                <table class="fd-table">
                  <tr>
                    <th>Scenario ID</th>
                    <th>Scenario Name</th>
                    <th>Capability ID</th>
                    <th>Capability Name</th>
                    <th>Capability Used</th>
                    <th>Check Status</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/COLLECTORS/item">

                    <tr>
                      <td><xsl:value-of select="SCENARIO_ID"/></td>
                      <td><xsl:value-of select="SCENARIO_NAME"/></td>
                      <td><xsl:value-of select="CAPABILITY_ID"/></td>
                      <td><xsl:value-of select="CAPABILITY_NAME"/></td>
                      <td><xsl:value-of select="CAPABILITY_USED"/></td>
                      <td><xsl:value-of select="CHECK_STATUS"/></td>
                    </tr>
                  </xsl:for-each>

                </table>

               

                
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>